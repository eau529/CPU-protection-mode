# 适用于mac
qemu-system-i386 -m 128M -s -S  -drive file=disk.img,index=0,media=disk,format=raw